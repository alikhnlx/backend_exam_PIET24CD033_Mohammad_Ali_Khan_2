# Library Book Management API

REST API for a college library built with Node.js, Express and MongoDB (Mongoose).

## File Mapping

| File | Role |
|------|------|
| `file/A1.js` | Server entry point (`server.js`): Express setup, logger middleware, MongoDB connection, error-handling middleware, port 3000 |
| `file/A2.js` | Book model (`models/`): Mongoose schema |
| `file/A3.js` | Book routes (`routes/`): CRUD endpoints |

## Setup

```bash
cd file
npm install
```

Set the MongoDB URL in `file/.env`:

```
MONGO_URL=mongodb://127.0.0.1:27017/librarydb
```

## Run

```bash
cd file
node A1.js
```

Server runs at `http://localhost:3000`.

## Book Schema

| Field | Type | Rules |
|-------|------|-------|
| title | String | required |
| author | String | required |
| price | Number | minimum 1 |
| category | String | optional |
| isAvailable | Boolean | default `true` |

## Endpoints

| Method | URL | Description | Success |
|--------|-----|-------------|---------|
| POST | `/books` | Add a book | 201 |
| GET | `/books` | List all books | 200 |
| GET | `/books/:id` | Get one book | 200 |
| PUT | `/books/:id` | Update a book | 200 |
| DELETE | `/books/:id` | Delete a book | 200 |

Errors: `400` for invalid input or invalid id, `404` when the book is not found.

## Sample Request Body

```json
{
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "price": 450,
  "category": "Programming"
}
```

## Outputs

Screenshots of each endpoint tested in Postman or Thunder Client, plus the data in MongoDB Compass, are stored in `outputs/` as `A1.png`, `A2.png` and `A3.png`.
